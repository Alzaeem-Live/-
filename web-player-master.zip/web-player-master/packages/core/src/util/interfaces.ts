import {ErrorCode} from "./constants";

export interface WebPlayerError {
	errorCode: ErrorCode
}
