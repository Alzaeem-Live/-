import WebPlayer, { PlayerEvent } from '@eyevinn/web-player-core';
import { renderEyevinnSkin } from '@eyevinn/web-player-eyevinn-skin';
import style from '@eyevinn/web-player-eyevinn-skin/dist/index.css';
import { PlayerAnalyticsConnector } from '@eyevinn/player-analytics-client-sdk-web';

const ComponentAttribute = {
  DYNAMIC: {
    SOURCE: 'source',
    STARTTIME: 'starttime',
    AUTOPLAY: 'autoplay',
    MUTED: 'muted',
  },
  STATIC: {
    AUTOPLAY_VISIBLE: 'autoplay-visible',
    ANALYTICS: 'analytics',
    EPAS_URL: 'epas-url',
    DISABLE_LEVEL_CAP: 'disable-level-cap',
  }
}

const isSet = (value) => value === "" || !!value;

export default class PlayerComponent extends HTMLElement {
  static get observedAttributes() {
    return Object.values(ComponentAttribute.DYNAMIC);
  };
  constructor() {
    super();
    const wrapper = this.setupDOM();

    // if we only want to play when in view, init observer
    const autoplay = this.getAttribute(ComponentAttribute.DYNAMIC.AUTOPLAY);
    const autoplayVisible = this.getAttribute(ComponentAttribute.STATIC.AUTOPLAY_VISIBLE);
    if (!isSet(autoplay) && isSet(autoplayVisible)) {
      this.observer = new IntersectionObserver(this.inViewHandler.bind(this));
      this.observer.observe(this.video);
    }

    const disablePlayerSizeLevelCap = this.getAttribute(ComponentAttribute.STATIC.DISABLE_LEVEL_CAP);
    this.setupPlayer(wrapper, disablePlayerSizeLevelCap);

    this.setupAnalytics({
      enabled: this.getAttribute(ComponentAttribute.STATIC.ANALYTICS),
      epasUrl: this.getAttribute(ComponentAttribute.STATIC.EPAS_URL)
    });

    this.setupPlayerEventListener();
  }

  setupDOM() {
    this.attachShadow({ mode: 'open' });
    const { shadowRoot } = this;

    let styleTag = document.createElement('style');
    styleTag.innerHTML = style;
    shadowRoot.appendChild(styleTag);

    // We create a wrapper to put the skin along with the video element
    const wrapper = document.createElement('div');
    shadowRoot.appendChild(wrapper);
    this.video = document.createElement('video');
    wrapper.appendChild(this.video);

    return wrapper;
  }

  setupPlayer(wrapper, disablePlayerSizeLevelCap) {
    this.player = new WebPlayer({
      video: this.video,
      disablePlayerSizeLevelCap: !!disablePlayerSizeLevelCap
    });
    renderEyevinnSkin({
      root: wrapper,
      player: this.player,
      castAppId: {}
    });
  }

  setupAnalytics({ enabled, epasUrl }) {
    this.playerAnalytics = null;
    if (isSet(enabled) && epasUrl) {
      this.playerAnalytics = new PlayerAnalyticsConnector(epasUrl);
    }
  }

  setupPlayerEventListener() {
    this.player.on(PlayerEvent.ERROR, ({ errorData, fatal }) => {
      console.error('player reported error', errorData);
      if (this.playerAnalytics) {
        if (fatal) {
          this.playerAnalytics.reportError(errorData);
        } else {
          this.playerAnalytics.reportWarning(errorData);
        }
      }
      if (fatal) {
        this.player.destroy();
        console.log('player destroyed due to error');
      }
    });

    this.player.on(PlayerEvent.BITRATE_CHANGE, (data) => {
      if (!this.playerAnalytics) return;
      this.playerAnalytics.reportBitrateChange({
        bitrate: data.bitrate / 1000,
        width: data.width,
        height: data.height,
      });
    });
  }

  async initAnalytics() {
    if (!this.playerAnalytics) return;
    try {
      await this.playerAnalytics.init({
        sessionId: `${window.location.hostname}-${Date.now()}`
      });
    } catch (err) {
      console.error(err);
      this.playerAnalytics.deinit();
      this.playerAnalytics = null;
    }
  }

  loadAnalytics() {
    if (!this.playerAnalytics) return;
    this.playerAnalytics.load(this.video);

    this.player.on(PlayerEvent.LOADED_METADATA, this.metadataReporter = () => {
      this.playerAnalytics.reportMetadata({
        live: this.player.isLive,
        contentUrl: this.getAttribute(ComponentAttribute.DYNAMIC.SOURCE),
      });
      this.player.off(PlayerEvent.LOADED_METADATA, this.metadataReporter);
    })
  }

  async attributeChangedCallback(name) {
    const src = this.getAttribute(ComponentAttribute.DYNAMIC.SOURCE);
    const starttime = this.getAttribute(ComponentAttribute.DYNAMIC.STARTTIME);
    const autoplay = this.getAttribute(ComponentAttribute.DYNAMIC.AUTOPLAY);
    const muted = this.getAttribute(ComponentAttribute.DYNAMIC.MUTED);

    if (name === ComponentAttribute.DYNAMIC.SOURCE) {
      if (isSet(src)) {
        await this.initAnalytics();
        await this.player.load(src);
        this.loadAnalytics();
        if (isSet(starttime)) {
          this.video.currentTime = starttime;
        }
        if (isSet(autoplay)) {
          this.video.muted = isSet(muted);
          this.video.autoplay = true;
          this.player.play();
        }
      }
      else {
        console.error("Invalid source was provided to <eyevinn-video> element");
      }
    }
    if (name === ComponentAttribute.DYNAMIC.MUTED) {
      this.video.muted = isSet(muted);
    }
  }

  connectedCallback() {
    this.setupEventProxy();
  }

  disconnectedCallback() {
    this.player.reset();
  }

  setupEventProxy() {
    if (!this.player) return;
    this.player.on('*', (event, data) => {
      this.dispatchEvent(new CustomEvent(event, { detail: data }));
    });
  }

  inViewHandler(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        this.video.muted = true;
        this.video.autoplay = true;
        this.player.play();
      } else if (
        this.player.isPlaying && !entry.isIntersecting
      ) {
        this.player.pause();
      }
    });
  }
}
customElements.define('eyevinn-video', PlayerComponent);
