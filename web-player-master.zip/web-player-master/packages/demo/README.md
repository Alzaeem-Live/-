# Demo

A simple demo implementation of the different packages that make up the Eyevinn WebPlayer.

Run `npm run dev` in the root of this repository to see it in action!